// Cody Marsh 1/13/2024 in class activity 2
public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("Don't think, feel! It's like a finger pointing away to the moon. Don't focus on the finger or you will miss all that heavenly glory.");
		System.out.println("Enter the Dragon");
		System.out.println("Lee");
		System.out.println("1973");

	}

}
