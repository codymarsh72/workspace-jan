// Cody Marsh 1/13/2024 In class activity 1
public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("Black ocean, cold and dark");
		System.out.println("I am the hungry shark, fast and merciless");
		System.out.println("But the only girl that could talk to him just couldn't swim");
		System.out.println("Tell me what's worse than this");

	}

}
